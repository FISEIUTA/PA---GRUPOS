﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SGA.Api.Context;
using SGA.Api.Models;

namespace SGA.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EstudianteCursoController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EstudianteCursoController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/EstudianteCurso
        [HttpPost]
        public async Task<IActionResult> MatricularEstudiante([FromBody] EstudianteCurso ec)
        {
            if (string.IsNullOrWhiteSpace(ec.EstudianteCedula) || ec.CursoId <= 0)
                return BadRequest("Faltan datos: cédula del estudiante o ID del curso.");

            var estudianteExiste = await _context.Personas
                .OfType<Estudiante>()
                .AnyAsync(e => e.Cedula == ec.EstudianteCedula);

            var cursoExiste = await _context.Cursos
                .AnyAsync(c => c.Id == ec.CursoId);

            if (!estudianteExiste)
                return NotFound("El estudiante no existe.");

            if (!cursoExiste)
                return NotFound("El curso no existe.");

            var yaMatriculado = await _context.EstudiantesCursos
                .AnyAsync(x => x.EstudianteCedula == ec.EstudianteCedula && x.CursoId == ec.CursoId);

            if (yaMatriculado)
                return BadRequest("El estudiante ya está matriculado en este curso.");

            _context.EstudiantesCursos.Add(ec);
            await _context.SaveChangesAsync();

            return Ok(ec);
        }

        // DELETE: api/EstudianteCurso/1234567890/5
        [HttpDelete("{cedula}/{cursoId}")]
        public async Task<IActionResult> Desmatricular(string cedula, int cursoId)
        {
            var matricula = await _context.EstudiantesCursos
                .FirstOrDefaultAsync(x => x.EstudianteCedula == cedula && x.CursoId == cursoId);

            if (matricula == null)
                return NotFound("No se encontró la matrícula.");

            _context.EstudiantesCursos.Remove(matricula);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
