﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SGA.Api.Context;
using SGA.Api.Models;

[Route("api/[controller]")]
[ApiController]
public class EstudianteController : ControllerBase
{
    private readonly AppDbContext _context;

    public EstudianteController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Estudiante>>> GetEstudiantes()
    {
        return await _context.Personas
            .OfType<Estudiante>()
            .ToListAsync();
    }

    [HttpGet("{cedula}")]
    public async Task<ActionResult<Estudiante>> GetEstudiantePorCedula(string cedula)
    {
        var estudiante = await _context.Personas
            .OfType<Estudiante>()
            .FirstOrDefaultAsync(e => e.Cedula == cedula);

        return estudiante == null ? NotFound() : Ok(estudiante);
    }

    [HttpPost]
    public async Task<ActionResult<Estudiante>> PostEstudiante(Estudiante estudiante)
    {
        _context.Personas.Add(estudiante);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetEstudiantePorCedula), new { cedula = estudiante.Cedula }, estudiante);
    }

    [HttpPut("{cedula}")]
    public async Task<IActionResult> PutEstudiante(string cedula, Estudiante estudiante)
    {
        if (cedula != estudiante.Cedula)
            return BadRequest();

        _context.Entry(estudiante).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{cedula}")]
    public async Task<IActionResult> DeleteEstudiante(string cedula)
    {
        var estudiante = await _context.Personas
            .OfType<Estudiante>()
            .FirstOrDefaultAsync(e => e.Cedula == cedula);

        if (estudiante == null) return NotFound();

        _context.Personas.Remove(estudiante);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
