﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SGA.Api.Context;
using SGA.Api.Models;

namespace WebApiSGA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfesorController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProfesorController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Profesor
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Profesor>>> GetProfesores()
        {
            return await _context.Personas
                .OfType<Profesor>()
                .Include(p => p.Cursos)
                .ToListAsync();
        }

        // GET: api/Profesor/cedula/1234567890
        [HttpGet("cedula/{cedula}")]
        public async Task<ActionResult<Profesor>> GetProfesor(string cedula)
        {
            var profesor = await _context.Personas
                .OfType<Profesor>()
                .Include(p => p.Cursos)
                .FirstOrDefaultAsync(p => p.Cedula == cedula);

            return profesor == null ? NotFound() : Ok(profesor);
        }

        // POST: api/Profesor
        [HttpPost]
        public async Task<ActionResult<Profesor>> PostProfesor(Profesor profesor)
        {
            _context.Personas.Add(profesor);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProfesor), new { cedula = profesor.Cedula }, profesor);
        }

        // PUT: api/Profesor/1234567890
        [HttpPut("{cedula}")]
        public async Task<IActionResult> PutProfesor(string cedula, Profesor profesor)
        {
            if (cedula != profesor.Cedula)
                return BadRequest();

            _context.Entry(profesor).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                var exists = await _context.Personas
                    .OfType<Profesor>()
                    .AnyAsync(p => p.Cedula == cedula);

                if (!exists)
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        // DELETE: api/Profesor/1234567890
        [HttpDelete("{cedula}")]
        public async Task<IActionResult> DeleteProfesor(string cedula)
        {
            var profesor = await _context.Personas
                .OfType<Profesor>()
                .FirstOrDefaultAsync(p => p.Cedula == cedula);

            if (profesor == null)
                return NotFound();

            _context.Personas.Remove(profesor);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
