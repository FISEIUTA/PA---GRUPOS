﻿using Microsoft.EntityFrameworkCore;
using SGA.Api.Context;
using Npgsql.EntityFrameworkCore.PostgreSQL;


var builder = WebApplication.CreateBuilder(args);

// 🟢 Conexión a base de datos existente
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql("Host=interchange.proxy.rlwy.net;Port=56434;Database=ferrocarril;Username=postgres;Password=whsYTQykszcjhwkeIecDRIAwhthPCWkZ"));


// 🟢 Servicios
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 🟢 Middleware solo en entorno de desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 🟢 Servir archivos estáticos (como index.html y script.js desde wwwroot)
app.UseStaticFiles();

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
