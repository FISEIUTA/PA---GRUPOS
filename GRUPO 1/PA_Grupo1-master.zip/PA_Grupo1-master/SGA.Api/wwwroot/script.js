﻿const API = window.location.origin;

// ----------- ESTUDIANTES -----------
document.getElementById("formEstudiante").addEventListener("submit", async function (e) {
    e.preventDefault();

    const cedulaInput = document.getElementById("estu_cedula");
    const nombreInput = document.getElementById("estu_nombre");
    const apellidoInput = document.getElementById("estu_apellido");

    const cedula = cedulaInput.value.trim();
    const nombre = nombreInput.value.trim().toUpperCase();
    const apellido = apellidoInput.value.trim().toUpperCase();
    const correo = document.getElementById("estu_correo").value.trim();
    const carrera = document.getElementById("estu_carrera").value.trim();

    // Reflejar el texto limpio
    nombreInput.value = nombre;
    apellidoInput.value = apellido;

    // Validar que la cédula tenga solo 10 números
    if (!/^\d{10}$/.test(cedula)) {
        alert("La cédula debe contener exactamente 10 dígitos numéricos.");
        return;
    }

    // Validar si la cédula ya existe
    const lista = await fetch(`${API}/api/Estudiante`);
    const estudiantes = await lista.json();
    const cedulaExiste = estudiantes.some(est => est.cedula === cedula);

    const advertencia = document.getElementById("estu_cedula_advertencia");

    if (cedulaExiste) {
        cedulaInput.style.backgroundColor = "#ffcccc";
        cedulaInput.title = "⚠️ Cédula ya registrada";
        advertencia.style.display = "inline";
        cedulaInput.focus();
        return;
    } else {
        cedulaInput.style.backgroundColor = "";
        cedulaInput.title = "";
        advertencia.style.display = "none";
    }

    // Validar nombre y apellido
    if (!/^[A-ZÁÉÍÓÚÑ\s]{1,50}$/.test(nombre)) {
        alert("El nombre debe tener solo letras mayúsculas (máx. 50 caracteres).");
        return;
    }

    if (!/^[A-ZÁÉÍÓÚÑ\s]{1,50}$/.test(apellido)) {
        alert("El apellido debe tener solo letras mayúsculas (máx. 50 caracteres).");
        return;
    }

    // Validar correo institucional
    if (!/^[\w\.-]+@uta\.edu\.ec$/.test(correo)) {
        alert("Ingrese un correo válido que termine en @uta.edu.ec.");
        return;
    }

    // Objeto
    const estudiante = {
        cedula,
        nombre,
        apellido,
        correo,
        carrera,
        tipoPersona: "Estudiante"
    };

    // Guardar
    const res = await fetch(`${API}/api/Estudiante`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(estudiante)
    });

    if (res.ok) {
        alert("Estudiante guardado correctamente.");
        listarEstudiantes();
        document.getElementById("formEstudiante").reset();
        cedulaInput.style.backgroundColor = "";
        cedulaInput.title = "";
        advertencia.style.display = "none";
    }
});



function mostrarModalBusqueda() {
    const modal = document.getElementById("modalBusquedaEstudiante");
    if (modal) {
        modal.style.display = "flex";
        document.getElementById("inputBusquedaCedula").value = "";
        document.getElementById("resultadoBusquedaEstudiante").innerHTML = "";
    }
}

function cerrarModalBusqueda() {
    const modal = document.getElementById("modalBusquedaEstudiante");
    if (modal) {
        modal.style.display = "none";
    }
}

async function buscarEstudiantePorCedula() {
    const cedula = document.getElementById("inputBusquedaCedula").value.trim();
    const resultado = document.getElementById("resultadoBusquedaEstudiante");

    if (!cedula || !/^\d{10}$/.test(cedula)) {
        resultado.innerHTML = `<p style="color: red;">Ingrese una cédula válida de 10 dígitos.</p>`;
        return;
    }

    try {
        const res = await fetch(`${API}/api/Estudiante/${cedula}`);
        if (!res.ok) {
            resultado.innerHTML = `<p style="color: red;">No se encontró un estudiante con esa cédula.</p>`;
            return;
        }

        const estudiante = await res.json();
        resultado.innerHTML = `
            <p><strong>Cédula:</strong> ${estudiante.cedula}</p>
            <p><strong>Nombre:</strong> ${estudiante.nombre}</p>
            <p><strong>Apellido:</strong> ${estudiante.apellido}</p>
            <p><strong>Correo:</strong> ${estudiante.correo}</p>
            <p><strong>Carrera:</strong> ${estudiante.carrera}</p>
        `;
    } catch (error) {
        resultado.innerHTML = `<p style="color: red;">Error al buscar estudiante.</p>`;
    }
}



async function listarEstudiantes() {
    const res = await fetch(`${API}/api/Estudiante`);
    const data = await res.json();
    const tbody = document.querySelector("#tablaEstudiantes tbody");
    tbody.innerHTML = "";
    data.forEach(est => {
        tbody.innerHTML += `
            <tr>
                <td>${est.cedula}</td>
                <td>${est.nombre}</td>
                <td>${est.apellido}</td>
                <td>${est.correo}</td>
                <td>${est.carrera}</td>
                <td>
                    <button onclick="editarEstudiante('${est.cedula}')">Editar</button>
                    <button onclick="eliminarEstudiante('${est.cedula}')">Eliminar</button>
                </td>
            </tr>`;
    });
    document.getElementById("tablaEstudiantes").style.display = "table";
}

async function editarEstudiante(cedula) {
    const res = await fetch(`${API}/api/Estudiante/${cedula}`);
    const est = await res.json();
    document.getElementById("estu_cedula").value = est.cedula;
    document.getElementById("estu_nombre").value = est.nombre;
    document.getElementById("estu_apellido").value = est.apellido;
    document.getElementById("estu_correo").value = est.correo;
    document.getElementById("estu_carrera").value = est.carrera;

    document.getElementById("formEstudiante").onsubmit = async function (e) {
        e.preventDefault();
        const actualizado = {
            cedula: est.cedula,
            nombre: document.getElementById("estu_nombre").value,
            apellido: document.getElementById("estu_apellido").value,
            correo: document.getElementById("estu_correo").value,
            carrera: document.getElementById("estu_carrera").value,
            tipoPersona: "Estudiante"
        };
        const putRes = await fetch(`${API}/api/Estudiante/${cedula}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(actualizado)
        });
        if (putRes.ok) {
            alert("Estudiante actualizado");
            document.getElementById("formEstudiante").reset();
            document.getElementById("formEstudiante").onsubmit = null;
            listarEstudiantes();
        }
    };
}

async function eliminarEstudiante(cedula) {
    if (confirm("¿Eliminar estudiante?")) {
        const res = await fetch(`${API}/api/Estudiante/${cedula}`, { method: "DELETE" });
        if (res.ok) {
            alert("Estudiante eliminado");
            listarEstudiantes();
        }
    }
}

// ----------- PROFESORES -----------
document.getElementById("formProfesor").addEventListener("submit", async function (e) {
    e.preventDefault();

    const cedulaInput = document.getElementById("prof_cedula");
    const nombreInput = document.getElementById("prof_nombre");
    const apellidoInput = document.getElementById("prof_apellido");

    const cedula = cedulaInput.value.trim();
    const nombre = nombreInput.value.trim().toUpperCase();
    const apellido = apellidoInput.value.trim().toUpperCase();
    const correo = document.getElementById("prof_correo").value.trim();
    const especialidad = document.getElementById("prof_especialidad").value.trim();

    // Reflejar valores limpios
    nombreInput.value = nombre;
    apellidoInput.value = apellido;

    // Validar cédula: 10 dígitos
    if (!/^\d{10}$/.test(cedula)) {
        alert("La cédula debe contener exactamente 10 dígitos numéricos.");
        return;
    }

    // Validar cédula repetida
    const lista = await fetch(`${API}/api/Profesor`);
    const profesores = await lista.json();
    const cedulaExiste = profesores.some(prof => prof.cedula === cedula);

    const advertencia = document.getElementById("prof_cedula_advertencia");

    if (cedulaExiste) {
        cedulaInput.style.backgroundColor = "#ffcccc";
        cedulaInput.title = "⚠️ Cédula ya registrada";
        advertencia.style.display = "inline";
        cedulaInput.focus();
        return;
    } else {
        cedulaInput.style.backgroundColor = "";
        cedulaInput.title = "";
        advertencia.style.display = "none";
    }

    // Validar nombre y apellido
    if (!/^[A-ZÁÉÍÓÚÑ\s]{1,50}$/.test(nombre)) {
        alert("El nombre debe tener solo letras mayúsculas (máx. 50 caracteres).");
        return;
    }

    if (!/^[A-ZÁÉÍÓÚÑ\s]{1,50}$/.test(apellido)) {
        alert("El apellido debe tener solo letras mayúsculas (máx. 50 caracteres).");
        return;
    }

    // Validar correo institucional
    if (!/^[\w\.-]+@uta\.edu\.ec$/.test(correo)) {
        alert("Ingrese un correo válido que termine en @uta.edu.ec.");
        return;
    }

    // Objeto
    const profesor = {
        cedula,
        nombre,
        apellido,
        correo,
        especialidad,
        tipoPersona: "Profesor"
    };

    const res = await fetch(`${API}/api/Profesor`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profesor)
    });

    if (res.ok) {
        alert("Profesor guardado correctamente.");
        listarProfesores();
        document.getElementById("formProfesor").reset();
        cedulaInput.style.backgroundColor = "";
        cedulaInput.title = "";
        advertencia.style.display = "none";
    }
});


function mostrarModalBusquedaProfesor() {
    document.getElementById("modalBusquedaProfesor").style.display = "block";
    document.getElementById("resultadoBusquedaProfesor").innerHTML = "";
    document.getElementById("cedulaBusquedaProfesor").value = "";
}

function cerrarModalBusquedaProfesor() {
    document.getElementById("modalBusquedaProfesor").style.display = "none";
}

async function buscarProfesorPorCedula() {
    const cedula = document.getElementById("cedulaBusquedaProfesor").value.trim();
    const resultado = document.getElementById("resultadoBusquedaProfesor");

    if (!cedula || !/^\d{10}$/.test(cedula)) {
        resultado.innerHTML = `<p style="color: red;">Ingrese una cédula válida de 10 dígitos.</p>`;
        return;
    }

    const res = await fetch(`${API}/api/Profesor/${cedula}`);
    if (!res.ok) {
        resultado.innerHTML = `<p style="color: red;">No se encontró un profesor con esa cédula.</p>`;
        return;
    }

    const profesor = await res.json();
    resultado.innerHTML = `
        <p><strong>Cédula:</strong> ${profesor.cedula}</p>
        <p><strong>Nombre:</strong> ${profesor.nombre}</p>
        <p><strong>Apellido:</strong> ${profesor.apellido}</p>
        <p><strong>Correo:</strong> ${profesor.correo}</p>
        <p><strong>Especialidad:</strong> ${profesor.especialidad}</p>
    `;
}


async function listarProfesores() {
    const res = await fetch(`${API}/api/Profesor`);
    const data = await res.json();
    const tbody = document.querySelector("#tablaProfesores tbody");
    tbody.innerHTML = "";
    data.forEach(p => {
        tbody.innerHTML += `
            <tr>
                <td>${p.cedula}</td>
                <td>${p.nombre}</td>
                <td>${p.apellido}</td>
                <td>${p.correo}</td>
                <td>${p.especialidad}</td>
                <td>
                    <button onclick="editarProfesor('${p.cedula}')">Editar</button>
                    <button onclick="eliminarProfesor('${p.cedula}')">Eliminar</button>
                </td>
            </tr>`;
    });
    document.getElementById("tablaProfesores").style.display = "table";
}

async function editarProfesor(cedula) {
    const res = await fetch(`${API}/api/Profesor/cedula/${cedula}`);
    const prof = await res.json();
    document.getElementById("prof_cedula").value = prof.cedula;
    document.getElementById("prof_nombre").value = prof.nombre;
    document.getElementById("prof_apellido").value = prof.apellido;
    document.getElementById("prof_correo").value = prof.correo;
    document.getElementById("prof_especialidad").value = prof.especialidad;

    document.getElementById("formProfesor").onsubmit = async function (e) {
        e.preventDefault();
        const actualizado = {
            cedula: prof.cedula,
            nombre: document.getElementById("prof_nombre").value,
            apellido: document.getElementById("prof_apellido").value,
            correo: document.getElementById("prof_correo").value,
            especialidad: document.getElementById("prof_especialidad").value,
            tipoPersona: "Profesor"
        };
        const putRes = await fetch(`${API}/api/Profesor/${cedula}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(actualizado)
        });
        if (putRes.ok) {
            alert("Profesor actualizado");
            document.getElementById("formProfesor").reset();
            document.getElementById("formProfesor").onsubmit = null;
            listarProfesores();
        }
    };
}

async function eliminarProfesor(cedula) {
    if (confirm("¿Eliminar profesor?")) {
        const res = await fetch(`${API}/api/Profesor/${cedula}`, { method: "DELETE" });
        if (res.ok) {
            alert("Profesor eliminado");
            listarProfesores();
        }
    }
}

// ---------------- CURSOS ----------------
document.getElementById("formCurso").addEventListener("submit", async function (e) {
    e.preventDefault();
    const id = parseInt(document.getElementById("curso_id").value) || 0;

    const curso = {
        id,
        nombre: document.getElementById("curso_nombre").value,
        descripcion: document.getElementById("curso_descripcion").value,
        paralelo: document.getElementById("curso_paralelo").value,
        profesorCedula: document.getElementById("curso_profesorCedula").value
    };

    const method = id > 0 ? "PUT" : "POST";
    const url = id > 0 ? `${API}/api/Cursos/${id}` : `${API}/api/Cursos`;

    const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(curso)
    });

    if (res.ok) {
        alert("Curso guardado correctamente");
        listarCursos();
        document.getElementById("formCurso").reset();
        document.getElementById("curso_id").value = 0;
    } else {
        const error = await res.text();
        alert("Error: " + error);
    }
});

async function listarCursos() {
    const res = await fetch(`${API}/api/Cursos`);
    const data = await res.json();
    const tbody = document.querySelector("#tablaCursos tbody");
    tbody.innerHTML = "";
    data.forEach(curso => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${curso.id}</td>
      <td>${curso.nombre}</td>
      <td>${curso.descripcion}</td>
      <td>${curso.paralelo}</td>
      <td>${curso.profesorCedula}</td>
      <td>
        <button onclick="editarCurso(${curso.id})">Editar</button>
        <button onclick="eliminarCurso(${curso.id})">Eliminar</button>
      </td>`;
        tbody.appendChild(tr);
    });
    document.getElementById("tablaCursos").style.display = "table";
}

async function editarCurso(id) {
    const res = await fetch(`${API}/api/Cursos/${id}`);
    const curso = await res.json();
    document.getElementById("curso_id").value = curso.id;
    document.getElementById("curso_nombre").value = curso.nombre;
    document.getElementById("curso_descripcion").value = curso.descripcion;
    document.getElementById("curso_paralelo").value = curso.paralelo;
    document.getElementById("curso_profesorCedula").value = curso.profesorCedula;
}

async function eliminarCurso(id) {
    if (confirm("¿Eliminar curso?")) {
        const res = await fetch(`${API}/api/Cursos/${id}`, { method: "DELETE" });
        if (res.ok) {
            alert("Curso eliminado");
            listarCursos();
        }
    }
}

// ---------------- MATRÍCULA ----------------
document.getElementById("formMatricula").addEventListener("submit", async function (e) {
    e.preventDefault();
    const matricula = {
        estudianteCedula: document.getElementById("matri_estudianteCedula").value,
        cursoId: parseInt(document.getElementById("matri_cursoId").value)
    };

    const res = await fetch(`${API}/api/EstudianteCurso`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(matricula)
    });

    if (res.ok) {
        alert("Estudiante matriculado");
        listarMatriculas();
    } else {
        const error = await res.text();
        alert("Error al matricular: " + error);
    }
});

async function listarMatriculas() {
    const cedula = document.getElementById("matri_estudianteCedula").value;
    const res = await fetch(`${API}/api/Cursos/por-estudiante/${cedula}`);
    const data = await res.json();
    const tbody = document.querySelector("#tablaMatriculas tbody");
    tbody.innerHTML = "";
    data.forEach(curso => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${curso.nombre}</td>
      <td>${curso.descripcion}</td>
      <td>${curso.paralelo}</td>
      <td>
        <button onclick="desmatricular('${cedula}', ${curso.id})">Eliminar</button>
      </td>`;
        tbody.appendChild(tr);
    });
    document.getElementById("tablaMatriculas").style.display = "table";
}

async function desmatricular(cedula, cursoId) {
    if (confirm("¿Eliminar matrícula?")) {
        const res = await fetch(`${API}/api/EstudianteCurso/${cedula}/${cursoId}`, {
            method: "DELETE"
        });
        if (res.ok) {
            alert("Matrícula eliminada");
            listarMatriculas();
        }
    }
}

async function cargarCursosParaMatricula() {
    try {
        const res = await fetch(`${API}/api/Cursos`);
        if (!res.ok) throw new Error("No se pudieron obtener los cursos");
        const cursos = await res.json();
        const select = document.getElementById("matri_cursoId");
        if (!select) {
            console.warn("No se encontró el combo 'matri_cursoId'");
            return;
        }

        select.innerHTML = ""; // Limpia las opciones anteriores
        cursos.forEach(curso => {
            const option = document.createElement("option");
            option.value = curso.id;
            option.text = `${curso.nombre} (${curso.paralelo})`;
            select.appendChild(option);
        });

        if (cursos.length === 0) {
            const option = document.createElement("option");
            option.text = "No hay cursos disponibles";
            option.disabled = true;
            select.appendChild(option);
        }

    } catch (error) {
        console.error("Error al cargar cursos:", error);
        alert("No se pudieron cargar los cursos.");
    }
}

// Llamada cuando se carga la página o cambia la pestaña
window.addEventListener("DOMContentLoaded", () => {
    cargarCursosParaMatricula(); // 👈 Esto asegura que se ejecute correctamente
});



// Llenar select al iniciar
cargarCursosParaMatricula();
