﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SGA.Api.Models
{
    public class Persona
    {
        [Key]
        [Column(TypeName = "varchar(20)")]
        public string Cedula { get; set; } = string.Empty;

        [Column(TypeName = "varchar(100)")]
        public string Nombre { get; set; } = string.Empty;

        [Column(TypeName = "varchar(100)")]
        public string Apellido { get; set; } = string.Empty;

        [Column(TypeName = "varchar(150)")]
        public string Correo { get; set; } = string.Empty;

        [Column(TypeName = "varchar(50)")]
        public string TipoPersona { get; set; } = string.Empty;
    }
}
