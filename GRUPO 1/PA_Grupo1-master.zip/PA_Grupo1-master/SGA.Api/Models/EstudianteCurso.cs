﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace SGA.Api.Models
{
    [Table("EstudiantesCursos")]
    public class EstudianteCurso
    {
        public string EstudianteCedula { get; set; } = string.Empty;

        [JsonIgnore]
        public Estudiante? Estudiante { get; set; }

        public int CursoId { get; set; }

        [JsonIgnore]
        public Curso? Curso { get; set; }
    }
}
