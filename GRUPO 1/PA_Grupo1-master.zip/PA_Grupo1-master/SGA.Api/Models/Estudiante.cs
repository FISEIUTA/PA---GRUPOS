﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using SGA.Api.Models;

[Table("Estudiantes")]
public class Estudiante : Persona
{
    public string Carrera { get; set; } = string.Empty;

    [JsonIgnore]
    public List<EstudianteCurso> EstudiantesCursos { get; set; } = new();

    public Estudiante()
    {
        TipoPersona = "Estudiante";
    }
}
