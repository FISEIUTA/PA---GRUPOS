﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace SGA.Api.Models
{
    [Table("Cursos")]
    public class Curso
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Descripcion { get; set; } = string.Empty;

        [MaxLength(5)]
        public string Paralelo { get; set; } = string.Empty;

        [Required]
        [ForeignKey("Profesor")]
        public string ProfesorCedula { get; set; } = string.Empty;

        [JsonIgnore]
        public Profesor? Profesor { get; set; }

        [JsonIgnore]
        public ICollection<EstudianteCurso> EstudiantesCursos { get; set; } = new List<EstudianteCurso>();
    }
}
