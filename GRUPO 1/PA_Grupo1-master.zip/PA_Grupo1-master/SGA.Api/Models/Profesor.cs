﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using SGA.Api.Models;

[Table("Profesores")]
public class Profesor : Persona
{
    public string Especialidad { get; set; } = string.Empty;

    public List<Curso> Cursos { get; set; } = new();

    public Profesor()
    {
        TipoPersona = "Profesor";
    }
}
