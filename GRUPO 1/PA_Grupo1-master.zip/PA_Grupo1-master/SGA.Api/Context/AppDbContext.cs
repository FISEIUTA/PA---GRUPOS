﻿using Microsoft.EntityFrameworkCore;
using SGA.Api.Models;

namespace SGA.Api.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Persona> Personas { get; set; }
        public DbSet<Curso> Cursos { get; set; }
        public DbSet<EstudianteCurso> EstudiantesCursos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // 🧠 Herencia con Discriminator (TPH)
            modelBuilder.Entity<Persona>()
                .ToTable("Personas")
                .HasDiscriminator<string>("TipoPersona")
                .HasValue<Estudiante>("Estudiante")
                .HasValue<Profesor>("Profesor");

            // Especificar tipos correctos para PostgreSQL
            modelBuilder.Entity<Persona>(entity =>
            {
                entity.Property(p => p.Cedula).HasColumnType("varchar(20)");
                entity.Property(p => p.Nombre).HasColumnType("text");
                entity.Property(p => p.Apellido).HasColumnType("text");
                entity.Property(p => p.Correo).HasColumnType("text");
                entity.Property(p => p.TipoPersona).HasColumnType("varchar(20)");
            });

            modelBuilder.Entity<Profesor>().ToTable("Personas");
            modelBuilder.Entity<Profesor>()
                .Property(p => p.Especialidad).HasColumnType("text");

            modelBuilder.Entity<Estudiante>().ToTable("Personas");
            modelBuilder.Entity<Estudiante>()
                .Property(e => e.Carrera).HasColumnType("text");

            modelBuilder.Entity<Curso>(entity =>
            {
                entity.Property(c => c.Nombre).HasColumnType("text");
                entity.Property(c => c.Descripcion).HasColumnType("text");
                entity.Property(c => c.Paralelo).HasColumnType("varchar(5)");
                entity.Property(c => c.ProfesorCedula).HasColumnType("varchar(20)");
            });

            // Relación muchos a muchos
            modelBuilder.Entity<EstudianteCurso>()
                .HasKey(ec => new { ec.EstudianteCedula, ec.CursoId });

            modelBuilder.Entity<EstudianteCurso>()
                .HasOne(ec => ec.Estudiante)
                .WithMany(e => e.EstudiantesCursos)
                .HasForeignKey(ec => ec.EstudianteCedula)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<EstudianteCurso>()
                .HasOne(ec => ec.Curso)
                .WithMany(c => c.EstudiantesCursos)
                .HasForeignKey(ec => ec.CursoId)
                .OnDelete(DeleteBehavior.Restrict);

            // Relación Curso - Profesor
            modelBuilder.Entity<Curso>()
                .HasOne(c => c.Profesor)
                .WithMany(p => p.Cursos)
                .HasForeignKey(c => c.ProfesorCedula)
                .OnDelete(DeleteBehavior.Restrict)
                .IsRequired(false);
        }
    }
}

