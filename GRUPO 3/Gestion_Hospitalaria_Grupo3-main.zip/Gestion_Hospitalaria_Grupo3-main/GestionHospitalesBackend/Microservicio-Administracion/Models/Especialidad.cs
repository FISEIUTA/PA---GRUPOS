﻿namespace Microservicio_Administracion.Models
{
    public class Especialidad
    {
        public int Id { get; set; }
        public string especialidad { get; set; }
    }
}
