﻿namespace Microservicio_Administracion.Models
{
    public class Tipo_Empleado
    {
        public int Id { get; set; }
        public string tipo { get; set; }
    }
}
