﻿namespace Microservicio_Administracion.Models
{
    public class Centro_Medico
    {
        public int Id { get; set; }
        public string nombre { get; set; }
        public string ciudad { get; set; }
        public string direccion { get; set; }
    }
}
